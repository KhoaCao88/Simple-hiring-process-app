package cdk.process.example.checkermaker.services;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cdk.process.example.checkermaker.models.FindApproverByApprovalLimit;

@Service
public class POApprovalSerivce extends ApprovalService{

    @Autowired
    ProcessEngine processEngine;

    @Override
    protected RequestInputs constructInputs(Approver candidate, RequestInputs inputs) {
        FindApproverByApprovalLimit localInputs = (FindApproverByApprovalLimit) inputs;
        localInputs.setApproverBand(candidate.getBand());
        return localInputs;
    }

    @Override
    protected List<Approver> fetchCandidates(RequestInputs inputs) {
        FindApproverByApprovalLimit localInputs = (FindApproverByApprovalLimit) inputs;
        ObjectMapper mapper = new ObjectMapper();
        String path = "/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/hr_hierarchy.json";
        try {
            Approver[] rawRecords = mapper.readValue(
                new FileInputStream(path), 
                Approver[].class);
            
            return (List) Arrays.asList(rawRecords);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected DmnDecisionResult getDMNDesicionResult(String serviceKey, Map<String, Object> vars) {
        return processEngine.getDecisionService()
            .evaluateDecisionByKey(serviceKey)
            .variables(vars)
            .evaluate();
    }

    @Override
    protected void sortCandidate(List<Approver> candidates) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public RequestInputs convertInputs(Object inputs) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(inputs, FindApproverByApprovalLimit.class);
    }
    
}