package com.singtel.wfaas.commonprocesses.factories;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApproverValidationService;
import com.singtel.wfaas.commonprocesses.services.implementations.DefaultApproverValidation;

import org.springframework.stereotype.Component;

@Component
public class DefaultApproverValidationServiceFactoryImp implements IApproverValidationServiceFactory{

    public static enum SERVICE_NAME {
        DefaultApproverValidation
    }

    @Override
    public ApproverValidationService iniService(String name, RequestInputs inputs, Approver approver) {
        
        switch(SERVICE_NAME.valueOf(name)){
            case DefaultApproverValidation:   
                return new DefaultApproverValidation.ValidationBuilder()
                        .withApproverActiveStatus(approver.getIsActive())
                        .withApproverOnleaveStatus(approver.getIsOnleave())
                        .withCreatorNameAndRequesterName(inputs.getCreatorId(), inputs.getRequesterId())
                        .buildValidator();

        }
        return null;
    }
    
}
