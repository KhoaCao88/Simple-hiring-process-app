package com.singtel.wfaas.commonprocesses.models;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FindApproverInputByHR extends RequestInputs{

    private int requesterManagerGrade;
    private int approverManagerGrade;
    private Double amount;
    private String band;
    
}
