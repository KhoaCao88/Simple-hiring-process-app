package com.singtel.wfaas.commonprocesses.services.implementations;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Service("HR-Approval-Service")
public class HRApprovalService extends ApprovalService{

    @Autowired
    ProcessEngine processEngine;;

    @Override
    protected List<Approver> fetchCandidates(RequestInputs inputs) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Approver[] rawRecords = mapper.readValue(
                new FileInputStream("/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/approvers.json"), 
                Approver[].class);
            
            return (List) Arrays.asList(rawRecords);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void sortCandidate(List<Approver> candidates) {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected DmnDecisionResult getDMNDesicionResult(String serviceKey, Map<String, Object> vars) {
        return processEngine.getDecisionService()
            .evaluateDecisionByKey(serviceKey)
            .variables(vars)
            .evaluate();
    }

    @Override
    protected RequestInputs constructInputs(Approver candidate, RequestInputs inputs) {
        FindApproverInputByHR inputByHR = (FindApproverInputByHR) inputs;
        inputByHR.setApproverManagerGrade(candidate.getManagerGrade());
        inputByHR.setBand(candidate.getBand());
        return inputByHR;
    }

    @Override
    public RequestInputs convertInputs(Object inputs) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(inputs, FindApproverInputByHR.class);
    }
}
