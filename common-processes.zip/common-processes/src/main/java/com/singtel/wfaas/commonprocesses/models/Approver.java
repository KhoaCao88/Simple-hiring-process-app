package com.singtel.wfaas.commonprocesses.models;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Approver implements Serializable{
    
    private String id;
    private String name;
    private String email;
    private int managerGrade; //1->4
    private String band;
    private Boolean isActive;
    private Boolean isOnleave;
    private Boolean isFinalApprover;
}
