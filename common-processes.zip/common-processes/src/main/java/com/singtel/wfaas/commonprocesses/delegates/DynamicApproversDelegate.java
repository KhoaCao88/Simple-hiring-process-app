package com.singtel.wfaas.commonprocesses.delegates;

import java.util.List;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Slf4j
@Component
@Setter
public class DynamicApproversDelegate implements JavaDelegate{

    @Autowired
    ProcessEngine processEngine;

    @Autowired
    private ApplicationContext context;

    private ApprovalService approvalService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
       
        String approvalServiceName = execution.getVariable("approvalServiceName") != null? 
                                        execution.getVariable("approvalServiceName").toString(): 
                                        "";

        log.info("Approval serivce name: {}", approvalServiceName);

        approvalService = approvalService == null? 
                            (ApprovalService)context.getBean(approvalServiceName):
                            approvalService;

        

        RequestInputs inputs = approvalService.convertInputs(execution.getVariable("requestInputs"));
        List<List<Approver>> approverHierarchy = approvalService.buildApprovalChain(inputs);
        execution.setVariable("approvers", approverHierarchy);
        execution.setVariable("index", 0);
        execution.setVariable("count", approverHierarchy.size());
        
    }
}