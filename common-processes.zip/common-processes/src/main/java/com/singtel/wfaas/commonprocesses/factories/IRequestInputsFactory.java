package com.singtel.wfaas.commonprocesses.factories;

import com.singtel.wfaas.commonprocesses.models.RequestInputs;

public interface IRequestInputsFactory {
    public RequestInputs iniRequestInputs(String name);
}
