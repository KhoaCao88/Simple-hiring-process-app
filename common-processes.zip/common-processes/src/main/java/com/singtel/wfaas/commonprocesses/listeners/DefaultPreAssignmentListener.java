package com.singtel.wfaas.commonprocesses.listeners;

import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.factories.DefaultApproverValidationServiceFactoryImp;
import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;
import com.singtel.wfaas.commonprocesses.services.ApproverValidationService;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Slf4j
@Component
@Setter
public class DefaultPreAssignmentListener implements TaskListener{

    @Autowired
    DefaultApproverValidationServiceFactoryImp defaultApproverValidationServiceFactory;

    @Autowired
    ApplicationContext context;

    ApprovalService approvalService;

    @Override
    public void notify(DelegateTask delegateTask) {
        //Get request inputs from process variable

        //Get approver validation service
        ObjectMapper mapper = new ObjectMapper();
        String approvalServiceName = delegateTask.getVariable("approvalServiceName") != null? 
                                        delegateTask.getVariable("approvalServiceName").toString(): 
                                        "";

        log.info("Approval serivce name: {}", approvalServiceName);

        approvalService = approvalService == null? 
                            (ApprovalService)context.getBean(approvalServiceName):
                            approvalService;

        RequestInputs inputs = approvalService.convertInputs(delegateTask.getVariable("requestInputs"));
        Approver approver = mapper.convertValue(delegateTask.getExecution().getVariableLocal("currentApprover"), Approver.class);

        String validationServiceName = delegateTask.getVariable("approverValidatorName") != null?
                                        delegateTask.getVariable("approverValidatorName").toString():
                                        DefaultApproverValidationServiceFactoryImp.SERVICE_NAME
                                            .DefaultApproverValidation.toString();

        ApproverValidationService validator = defaultApproverValidationServiceFactory
                                            .iniService(validationServiceName, inputs, approver);
        Map<String, Boolean> violations = validator.validate(approver);
        if(!validator.isAllPassed()){
            //Exception handler
            log.warn("Approver is invalid: {}", violations);
        }
    }
    
}
