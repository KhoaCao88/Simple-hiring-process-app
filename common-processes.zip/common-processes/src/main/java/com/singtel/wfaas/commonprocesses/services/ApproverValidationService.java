package com.singtel.wfaas.commonprocesses.services;

import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;

public interface ApproverValidationService {
    
    public Map<String, Boolean> validate(Approver approver);
    public Boolean isAllPassed();

}
