package com.singtel.wfaas.commonprocesses.services.implementations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.services.ApproverValidationService;

import org.springframework.stereotype.Service;

import lombok.Getter;
import lombok.Setter;

@Service
@Setter @Getter
public class DefaultApproverValidation implements ApproverValidationService{

    public static enum DEFAULT_APPROVER_RULES{
        APPROVER_CANT_BE_CREATOR_REQUESTER,
        APPROVER_MUST_BE_ACTIVE,
        APPROVER_MUST_NOT_ONLEAVE
    }

    private String requesterName;
    private String creatorName;
    private Boolean isActive;
    private Boolean isOnleave;
    private Map<String, Boolean> results;

    public static class ValidationBuilder{

        private String requesterName;
        private String creatorName;
        private Boolean isActive;
        private Boolean isOnleave;

        public ValidationBuilder(){

        }

        public ValidationBuilder withCreatorNameAndRequesterName(String creatorName, String requesterName){
            this.creatorName = creatorName;
            this.requesterName = requesterName;
            return this;
        }

        public ValidationBuilder withApproverActiveStatus(Boolean isActive){
            this.isActive = isActive;
            return this;
        }

        public ValidationBuilder withApproverOnleaveStatus(Boolean isOnleave){
            this.isOnleave = isOnleave;
            return this;
        }

        public DefaultApproverValidation buildValidator(){

            DefaultApproverValidation defaultApproverValidation = new DefaultApproverValidation();

            defaultApproverValidation.requesterName = this.requesterName;
            defaultApproverValidation.creatorName = this.creatorName;
            defaultApproverValidation.isActive = this.isActive;
            defaultApproverValidation.isOnleave = this.isOnleave;

            return defaultApproverValidation;
        }
    }

    private DefaultApproverValidation(){

    }

    @Override
    public Map<String, Boolean> validate(Approver approver) {

        this.results = new HashMap<String, Boolean>();
        if(this.requesterName != null && this.creatorName != null && approver.getIsFinalApprover()){
            if(!approver.getId().equals(requesterName) && 
                !approver.getId().equals(creatorName)){
                    
                this.results.put(DEFAULT_APPROVER_RULES.APPROVER_CANT_BE_CREATOR_REQUESTER.toString(), true);
            }else{
                this.results.put(DEFAULT_APPROVER_RULES.APPROVER_CANT_BE_CREATOR_REQUESTER.toString(), false);
            }
        }

        if(this.isActive != null){
            this.results.put(DEFAULT_APPROVER_RULES.APPROVER_MUST_BE_ACTIVE.toString(), this.isActive);
        }

        if(this.isOnleave != null){
            this.results.put(DEFAULT_APPROVER_RULES.APPROVER_MUST_NOT_ONLEAVE.toString(), !this.isOnleave);
        }

        return results;
    }

    @Override
    public Boolean isAllPassed() {
        
        for (String ruleName : results.keySet()) {
            if(!results.get(ruleName)){
                return false;
            }
        }
        return true;
    }
    
}