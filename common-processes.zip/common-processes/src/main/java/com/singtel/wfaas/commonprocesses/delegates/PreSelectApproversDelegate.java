package com.singtel.wfaas.commonprocesses.delegates;

import java.util.ArrayList;
import java.util.List;

import com.singtel.wfaas.commonprocesses.models.Approver;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Default find approver delegate for find approver service on the process
 * Must set currApprovers and isSingle to continue.
 * currApprovers <List of Approver>: for the current approval task
 * isSingle <Boolean>: is true if if currApprovers only has 1 approver
 */
@Slf4j
@Service
public class PreSelectApproversDelegate implements JavaDelegate{

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        log.info("Start Default Get approver service");
        ObjectMapper mapper = new ObjectMapper();
        List<List<Object>> approvers = mapper.convertValue(execution.getVariable("approvers"), ArrayList.class) ;
        log.info("Approvers: {}, size: {}", approvers, approvers.size());
        int currIndex = Integer.valueOf(execution.getVariable("index").toString());
        int count = Integer.valueOf(execution.getVariable("count").toString());
        Boolean isFinalApproval = currIndex < count - 1? false: true;
        log.info("currIndex: {}, total: {}, isFinalApprover: {}", currIndex, count, isFinalApproval);
        List<Object> currApprovers = approvers.get(currIndex);
        
        for (int i = 0; i < currApprovers.size(); i++) {
            log.info("Current Approver: {}", currApprovers.get(i));
            Approver tmp = mapper.convertValue(currApprovers.get(i), Approver.class);
            log.info("Current Approver after converting: {}", tmp);
            tmp.setIsFinalApprover(isFinalApproval);
            currApprovers.set(i, tmp);
        }

        // currApprovers.stream().forEach(item -> {
        //         log.info("Current Approver: {}", item);
        //         item.setIsFinalApprover(isFinalApproval);
        //     }
        // );
        log.info("Current approvers: {}", currApprovers);
        execution.setVariable("currApprovers",currApprovers);
        if(currApprovers.size() == 1){
            execution.setVariable("isSingle",true);
        }else{
            execution.setVariable("isSingle",false);
        }
    }
    
}
