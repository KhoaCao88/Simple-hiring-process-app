package com.singtel.wfaas.commonprocesses.factories;

import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;

public class DefaultRequestInputsFactoryImp implements IRequestInputsFactory{

    public static enum INPUT_TYPES{
        HR
    }

    @Override
    public RequestInputs iniRequestInputs(String name) {

        switch(INPUT_TYPES.valueOf(name)){
            case HR:
                return new FindApproverInputByHR();
        }
        
        return null;
    }
    
}
