package com.singtel.wfaas.commonprocesses.models;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RequestInputs implements Serializable{
    
    private String requestNo;
    private String creatorId;
    private String requesterId;
    private String decisionServiceName;
    private Boolean isSequential;
    private Integer maxApprovalLevels = 1;
    // private Approver approver;
}
