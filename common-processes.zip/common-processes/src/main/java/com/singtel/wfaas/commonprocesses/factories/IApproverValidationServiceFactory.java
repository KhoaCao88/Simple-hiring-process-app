package com.singtel.wfaas.commonprocesses.factories;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApproverValidationService;

public interface IApproverValidationServiceFactory {
    
    public ApproverValidationService iniService(String name, RequestInputs inputs, Approver approver);

}
