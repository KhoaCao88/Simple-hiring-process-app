package com.singtel.wfaas.commonprocesses.services;

public abstract class ApproverAssisngmentExceptionhandler {
    
}
