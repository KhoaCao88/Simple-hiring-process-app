package com.singtel.wfaas.commonprocesses.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;

import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.engine.DecisionService;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Slf4j
public abstract class ApprovalService {
    
    protected abstract List<Approver> fetchCandidates(RequestInputs inputs);

    protected abstract void sortCandidate(List<Approver> candidates);

    protected abstract RequestInputs constructInputs(Approver candidate, RequestInputs inputs);

    protected abstract DmnDecisionResult getDMNDesicionResult(String serviceKey, Map<String, Object> vars);

    public abstract RequestInputs convertInputs(Object inputs);

    public List<List<Approver>> buildApprovalChain(RequestInputs inputs){
        List<Approver> candidates = fetchCandidates(inputs);
        sortCandidate(candidates);

        List<List<Approver>> validCandidates = new ArrayList<List<Approver>>();
        ObjectMapper mapper = new ObjectMapper();
        for(int i = 0; i < candidates.size(); i++){
            if(validCandidates.size() == inputs.getMaxApprovalLevels()){
                break;
            }
            constructInputs(candidates.get(i), inputs);
            Map<String, Object> vars = mapper.convertValue(inputs, Map.class);
            DmnDecisionResult decisionResult = getDMNDesicionResult(inputs.getDecisionServiceName(), vars);
            
            if(decisionResult != null && !decisionResult.isEmpty()){
                log.info("rule: {}", decisionResult.getSingleResult().getEntry("remark").toString());
                if(inputs.getIsSequential()){
                    validCandidates.add(new ArrayList<Approver>()); // add more list
                    validCandidates.get(validCandidates.size() - 1).add(candidates.get(i)); // add 1 approver to newly created list
                }else{
                    if(validCandidates.size() == 0){
                        validCandidates.add(new ArrayList<Approver>()); // add 1 list if there is no list
                    }
                    validCandidates.get(0).add(candidates.get(i)); // append to 1st list
                }
            }
        }
        return validCandidates;
    }
}
