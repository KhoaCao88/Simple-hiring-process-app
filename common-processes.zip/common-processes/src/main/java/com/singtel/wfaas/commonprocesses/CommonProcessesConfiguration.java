package com.singtel.wfaas.commonprocesses;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScans({
	@ComponentScan("com.singtel.wfaas.commonprocesses.models"),
	@ComponentScan("com.singtel.wfaas.commonprocesses.services"),
	@ComponentScan("com.singtel.wfaas.commonprocesses.factories"),
	@ComponentScan("com.singtel.wfaas.commonprocesses.listeners"),
	@ComponentScan("com.singtel.wfaas.commonprocesses.delegates")
	
})
public class CommonProcessesConfiguration {

}
