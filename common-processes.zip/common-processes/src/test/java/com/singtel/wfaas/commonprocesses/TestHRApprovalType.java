package com.singtel.wfaas.commonprocesses;

import java.util.List;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.test.DmnEngineRule;
import org.camunda.bpm.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestHRApprovalType {

    @Rule
    public DmnEngineRule dmnEngineRule = new DmnEngineRule();

    @Test
    public void testLoadProfile() throws Exception{

        ApprovalService approverService = new HRApprovalService_TEST(dmnEngineRule);
        FindApproverInputByHR inputs = new FindApproverInputByHR();
        inputs.setIsSequential(true);
        inputs.setRequesterId("123");
        inputs.setRequesterManagerGrade(2);
        inputs.setAmount(150000.0);
        List<List<Approver>> approvers = approverService.buildApprovalChain(inputs);
        log.info("approvers: {}", approvers);
    }
}
