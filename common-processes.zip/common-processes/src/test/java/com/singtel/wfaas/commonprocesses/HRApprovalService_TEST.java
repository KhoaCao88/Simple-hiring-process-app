package com.singtel.wfaas.commonprocesses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.assertj.core.util.Arrays;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.test.DmnEngineRule;

import lombok.AllArgsConstructor;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@AllArgsConstructor
public class HRApprovalService_TEST extends ApprovalService{

    public DmnEngineRule dmnEngineRule;


    @Override
    protected List<Approver> fetchCandidates(RequestInputs inputs) {
        
        ObjectMapper mapper = new ObjectMapper();
        try {
            Approver[] rawRecords = mapper.readValue(
                new FileInputStream("/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/approvers.json"), 
                Approver[].class);
            
            return (List) Arrays.asList(rawRecords);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void sortCandidate(List<Approver> candidates) {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected DmnDecisionResult getDMNDesicionResult(String serviceKey, Map<String, Object> vars) {
        DmnEngine dmnEngine = dmnEngineRule.getDmnEngine();
        InputStream inputStream;
        try {
            inputStream = new FileInputStream("/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/HR_test.dmn");
            DmnDecision decision = dmnEngine.parseDecision(serviceKey, inputStream);
            return dmnEngine.evaluateDecision(decision, vars);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected RequestInputs constructInputs(Approver candidate, RequestInputs inputs) {
        FindApproverInputByHR inputByHR = (FindApproverInputByHR) inputs;
        inputByHR.setApproverManagerGrade(candidate.getManagerGrade());
        inputByHR.setBand(candidate.getBand());
        return inputByHR;
    }

    @Override
    public RequestInputs convertInputs(Object inputs) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(inputs, FindApproverInputByHR.class);
    }
   
}
