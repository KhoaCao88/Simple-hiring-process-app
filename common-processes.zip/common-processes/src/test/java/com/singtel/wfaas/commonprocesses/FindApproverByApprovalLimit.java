package com.singtel.wfaas.commonprocesses;

import com.singtel.wfaas.commonprocesses.models.RequestInputs;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class FindApproverByApprovalLimit extends RequestInputs {
    
    public final static String POT_TYPE_ONE_TIME = "One-time PO";
    public final static String POT_TYPE_CONTRACT_BASED = "Contract Based";
    public final static String POT_TYPE_ANY = "ANY";

    private String requesterId;
    private String creatorId;
    private Double amount;
    private String approvalType;
    private String approverBand;
    private Boolean isConsultancy;
    private String poType;
}
