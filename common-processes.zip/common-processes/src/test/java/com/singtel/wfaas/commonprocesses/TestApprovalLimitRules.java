package com.singtel.wfaas.commonprocesses;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.dmn.engine.test.DmnEngineRule;
import org.junit.Rule;
import org.junit.Test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestApprovalLimitRules {

    @Rule
    public DmnEngineRule dmnEngineRule = new DmnEngineRule();

    private List<List<Approver>> findApprover(Double amount, Boolean consultancy, String POType){

        ApprovalService approverService = new POApprovalServive_TEST(dmnEngineRule);
        FindApproverByApprovalLimit inputs = new FindApproverByApprovalLimit();
        inputs.setIsSequential(true);
        inputs.setRequesterId("123");
        inputs.setAmount(amount);
        inputs.setIsConsultancy(consultancy);
        inputs.setPoType(POType);
        inputs.setApprovalType("HR");
        inputs.setDecisionServiceName("po_approval_limit_competitive_sourcing");
        return approverService.buildApprovalChain(inputs);
    }

    @Test
    public void test_less_than_50K_one_time_PO_non_consultancy(){

        log.info("---test_less_than_50K_one_time_PO_non_consultancy---");
        List<List<Approver>> approvers = findApprover(5000.0, false, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("E", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_50K_one_time_PO_non_consultancy---");
    }

    @Test
    public void test_less_than_50K_contract_based_non_consultancy(){

        log.info("---test_less_than_50K_contract_based_non_consultancy---");
        List<List<Approver>> approvers = findApprover(5000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("E", approvers.get(0).get(0).getBand(), "");
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_50K_contract_based_non_consultancy---");
    }
    
    @Test
    public void test_less_than_50K_one_time_consultancy(){

        log.info("---test_less_than_50K_one_time_consultancy---");
        List<List<Approver>> approvers = findApprover(5000.0, true, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("C", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_50K_one_time_consultancy---");
    }

    @Test
    public void test_less_than_50K_contract_based_consultancy(){

        log.info("---test_less_than_50K_contract_based_consultancy---");
        List<List<Approver>> approvers = findApprover(5000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("E", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_50K_contract_based_consultancy---");
    }

    @Test
    public void test_less_than_100K_one_time_PO_non_consultancy(){

        log.info("---test_less_than_100K_one_time_PO_non_consultancy---");
        List<List<Approver>> approvers = findApprover(60000.0, false, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_100K_one_time_PO_non_consultancy---");
    }

    @Test
    public void test_less_than_100K_contract_based_non_consultancy(){

        log.info("---test_less_than_100K_contract_based_non_consultancy---");
        List<List<Approver>> approvers = findApprover(60000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand(), "");
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_100K_contract_based_non_consultancy---");
    }

    @Test
    public void test_less_than_100K_one_time_PO_consultancy(){

        log.info("---test_less_than_100K_one_time_PO_nconsultancy---");
        List<List<Approver>> approvers = findApprover(60000.0, true, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("B", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_100K_one_time_PO_nconsultancy---");
    }

    @Test
    public void test_less_than_100K_contract_based_consultancy(){

        log.info("---test_less_than_100K_contract_based_consultancy---");
        List<List<Approver>> approvers = findApprover(60000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_100K_contract_based_consultancy---");
    }

    @Test
    public void test_less_than_200K_one_time_PO_non_consultancy(){

        log.info("---test_less_than_200K_one_time_PO_non_consultancy---");
        List<List<Approver>> approvers = findApprover(150000.0, false, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_200K_one_time_PO_non_consultancy---");
    }

    @Test
    public void test_less_than_200K_contract_based_non_consultancy(){

        log.info("---test_less_than_200K_contract_based_non_consultancy---");
        List<List<Approver>> approvers = findApprover(150000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand(), "");
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_200K_contract_based_non_consultancy---");
    }

    @Test
    public void test_less_than_200K_one_time_PO_consultancy(){

        log.info("---test_less_than_200K_one_time_PO_consultancy---");
        List<List<Approver>> approvers = findApprover(150000.0, true, FindApproverByApprovalLimit.POT_TYPE_ONE_TIME);
        assertEquals("A", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_200K_one_time_PO_consultancy---");
    }

    @Test
    public void test_less_than_200K_contract_based_consultancy(){

        log.info("---test_less_than_200K_contract_based_consultancy---");
        List<List<Approver>> approvers = findApprover(150000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_200K_contract_based_consultancy---");
    }

    @Test
    public void test_less_than_500K_non_consultancy(){

        log.info("---test_less_than_500K_non_consultancy---");
        List<List<Approver>> approvers = findApprover(300000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_500K_non_consultancy---");
    }

    @Test
    public void test_less_than_500K_consultancy(){

        log.info("---test_less_than_500K_consultancy---");
        List<List<Approver>> approvers = findApprover(300000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("D", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_500K_consultancy---");
    }

    @Test
    public void test_less_than_1mil_non_consultancy(){

        log.info("---test_less_than_1mil_non_consultancy---");
        List<List<Approver>> approvers = findApprover(600000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("C", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_1mil_non_consultancy---");
    }

    @Test
    public void test_less_than_1mil_consultancy(){

        log.info("---test_less_than_1mil_consultancy---");
        List<List<Approver>> approvers = findApprover(600000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("C", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_1mil_consultancy---");
    }

    @Test
    public void test_less_than_3mil_non_consultancy(){

        log.info("---test_less_than_3mil_non_consultancy---");
        List<List<Approver>> approvers = findApprover(2000000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("B", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_3mil_non_consultancy---");
    }

    @Test
    public void test_less_than_3mil_consultancy(){

        log.info("---test_less_than_3mil_consultancy---");
        List<List<Approver>> approvers = findApprover(2000000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("B", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_less_than_3mil_consultancy---");
    }

    @Test
    public void test_more_than_3mil_non_consultancy(){

        log.info("---test_more_than_3mil_non_consultancy---");
        List<List<Approver>> approvers = findApprover(4000000.0, false, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("B", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_more_than_3mil_non_consultancy---");
    }

    @Test
    public void test_more_than_3mil_consultancy(){

        log.info("---test_more_than_3mil_consultancy---");
        List<List<Approver>> approvers = findApprover(4000000.0, true, FindApproverByApprovalLimit.POT_TYPE_CONTRACT_BASED);
        assertEquals("B", approvers.get(0).get(0).getBand());
        log.info("approvers: {}", approvers.get(0).get(0).getName());
        log.info("---test_more_than_3mil_consultancy---");
    }
}
