package com.singtel.wfaas.commonprocesses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;
import com.singtel.wfaas.commonprocesses.services.ApprovalService;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.test.DmnEngineRule;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Getter
@Setter
@AllArgsConstructor
public class POApprovalServive_TEST extends ApprovalService{

    DmnEngineRule dmnEngineRule;

    @Override
    protected List<Approver> fetchCandidates(RequestInputs inputs) {
        FindApproverByApprovalLimit localInputs = (FindApproverByApprovalLimit) inputs;
        ObjectMapper mapper = new ObjectMapper();
        String path = localInputs.getApprovalType().equals("HR")?
                        "/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/hr_hierarchy.json":
                        "/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/purchasing_group.json";
        try {
            Approver[] rawRecords = mapper.readValue(
                new FileInputStream(path), 
                Approver[].class);
            
            return (List) Arrays.asList(rawRecords);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void sortCandidate(List<Approver> candidates) {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected RequestInputs constructInputs(Approver candidate, RequestInputs inputs) {
        FindApproverByApprovalLimit localInputs = (FindApproverByApprovalLimit) inputs;
        localInputs.setApproverBand(candidate.getBand());
        return localInputs;
    }

    @Override
    public RequestInputs convertInputs(Object inputs) {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(inputs, FindApproverByApprovalLimit.class);
    }

    @Override
    protected DmnDecisionResult getDMNDesicionResult(String serviceKey, Map<String, Object> vars) {
        DmnEngine dmnEngine = dmnEngineRule.getDmnEngine();
        InputStream inputStream;
        try {
            inputStream = new FileInputStream("/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/Approval_limit.dmn");
            DmnDecision decision = dmnEngine.parseDecision(serviceKey, inputStream);
            return dmnEngine.evaluateDecision(decision, vars);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }
    
}
