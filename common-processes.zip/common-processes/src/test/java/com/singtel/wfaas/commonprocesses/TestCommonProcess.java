package com.singtel.wfaas.commonprocesses;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.singtel.wfaas.commonprocesses.delegates.DynamicApproversDelegate;
import com.singtel.wfaas.commonprocesses.delegates.PreSelectApproversDelegate;
import com.singtel.wfaas.commonprocesses.factories.DefaultApproverValidationServiceFactoryImp;
import com.singtel.wfaas.commonprocesses.listeners.DefaultPreAssignmentListener;
import com.singtel.wfaas.commonprocesses.models.Approver;
import com.singtel.wfaas.commonprocesses.models.FindApproverInputByHR;
import com.singtel.wfaas.commonprocesses.models.RequestInputs;

import org.camunda.bpm.dmn.engine.test.DmnEngineRule;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.engine.test.Deployment;
import org.camunda.bpm.engine.test.ProcessEngineRule;
import org.camunda.bpm.engine.test.mock.Mocks;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import lombok.extern.slf4j.Slf4j;
import spinjar.com.fasterxml.jackson.databind.ObjectMapper;

@Slf4j
@Deployment(resources = {"processes/common-approval.bpmn"})
public class TestCommonProcess {

    @Rule
    public ProcessEngineRule processEngineRule = new ProcessEngineRule();

    @Rule
    public DmnEngineRule dmnEngineRule = new DmnEngineRule();

    public static final String PROCESS_KEY = "CAP";

    List<List<Approver>> sequentApprovers = new ArrayList<>();
    List<List<Approver>> parallelApprovers = new ArrayList<>();


    @Before
    public void setup() {
        PreSelectApproversDelegate preSelectApproversDelegate = new PreSelectApproversDelegate();
        DefaultPreAssignmentListener defaultPreAssignmentListener = new DefaultPreAssignmentListener();
        DefaultApproverValidationServiceFactoryImp defaultApproverValidationServiceFactoryImp
        = new DefaultApproverValidationServiceFactoryImp();
        defaultPreAssignmentListener.setDefaultApproverValidationServiceFactory(defaultApproverValidationServiceFactoryImp);
        defaultPreAssignmentListener.setApprovalService(new HRApprovalService_TEST(dmnEngineRule));

        DynamicApproversDelegate dynamicApproversDelegate = new DynamicApproversDelegate();
        dynamicApproversDelegate.setProcessEngine(processEngineRule.getProcessEngine());
        dynamicApproversDelegate.setApprovalService(new HRApprovalService_TEST(dmnEngineRule));

        Mocks.register("preSelectApproversDelegate", preSelectApproversDelegate);
        Mocks.register("defaultPreAssignmentListener", defaultPreAssignmentListener);
        Mocks.register("dynamicApproversDelegate", dynamicApproversDelegate);

        try {
            ObjectMapper mapper = new ObjectMapper();
            Approver[] rawRecords = mapper.readValue(
                    new FileInputStream("/Users/khoacao/OneDrive/Projects/poc/common-processes/src/test/resources/approvers.json"), 
                    Approver[].class);
            List<Approver> approvers =  Arrays.asList(rawRecords);
            parallelApprovers.add(approvers);
            
            approvers.stream().forEach(approver -> 
            {
                List<Approver> a =  new ArrayList<Approver>();
                a.add(approver);
                sequentApprovers.add(a);
            });
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Test
    public void testCustomApproverHierarchy() {

        RequestInputs inputs = new RequestInputs();
        inputs.setRequesterId("11111");
        inputs.setCreatorId("11111");
        inputs.setIsSequential(true);
        inputs.setRequestNo("1323213213");
        inputs.setDecisionServiceName("HR-PO-table");

        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("approvalType", "NONE");
        variables.put("approvers", sequentApprovers);
        variables.put("requestInputs", inputs);

        ProcessInstance processInstance = processEngineRule.getRuntimeService()
                                            .startProcessInstanceByKey(PROCESS_KEY, variables);
        assertNotEquals(processInstance, null);
        
        Integer count = 0;
        while(processEngineRule.getTaskService().createTaskQuery().processInstanceId(processInstance.getId()).count() > 0){

            Task task = processEngineRule.getTaskService().createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
            log.info("Task name: {}, assignee: {}", task.getName(), task.getAssignee());
            assertEquals(String.valueOf(++count), task.getAssignee());
            Map<String, Object> approvalVar = new HashMap<String, Object>();
            approvalVar.put("approved", true);
            processEngineRule.getTaskService().complete(task.getId(), approvalVar);
        }
        
    }

    @Test
    public void testHRHierarchy_ManagerGradeBiggerThan2(){

        FindApproverInputByHR inputs = new FindApproverInputByHR();
        inputs.setRequesterId("1");
        inputs.setCreatorId("11111");
        inputs.setIsSequential(true);
        inputs.setRequestNo("1323213213");
        inputs.setDecisionServiceName("COI-table");
        inputs.setRequesterManagerGrade(1);

        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("approvalType", "HR");
        variables.put("approvers", sequentApprovers);
        variables.put("requestInputs", inputs);

        ProcessInstance processInstance = processEngineRule.getRuntimeService()
                                            .startProcessInstanceByKey(PROCESS_KEY, variables);
        assertNotEquals(processInstance, null);

        Integer count = 0;
        while(processEngineRule.getTaskService().createTaskQuery().processInstanceId(processInstance.getId()).count() > 0){

            Task task = processEngineRule.getTaskService().createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
            log.info("Task name: {}, assignee: {}", task.getName(), task.getAssignee());
            Map<String, Object> approvalVar = new HashMap<String, Object>();
            approvalVar.put("approved", true);
            processEngineRule.getTaskService().complete(task.getId(), approvalVar);
        }

    }
    
}
